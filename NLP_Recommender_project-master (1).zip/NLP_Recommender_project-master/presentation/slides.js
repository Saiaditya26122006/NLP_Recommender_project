"use strict";
const pptxgen = require("pptxgenjs");
const path = require("path");

const ROOT = path.resolve(__dirname, "..");
const CHARTS = path.join(ROOT, "analysis", "charts");
const OUT    = path.join(__dirname, "BookRecommender_Presentation.pptx");

// ── PALETTE ──────────────────────────────────────────────────────────────────
const NAVY   = "1E3A5F";
const GOLD   = "C4922A";
const CREAM  = "F5F0E8";
const WHITE  = "FFFFFF";
const DARK   = "1A1A2E";
const MUTED  = "7B8EA0";
const TEAL   = "2A7F8C";
const LIGHT_CARD = "EEE8DC";

const makeShadow = () => ({ type: "outer", color: "000000", blur: 8, offset: 3, angle: 135, opacity: 0.12 });

// ── HELPERS ──────────────────────────────────────────────────────────────────
function darkSlide(pres) {
  const s = pres.addSlide();
  s.background = { color: NAVY };
  return s;
}

function lightSlide(pres) {
  const s = pres.addSlide();
  s.background = { color: CREAM };
  return s;
}

// Slide header: gold left bar + title text
function addHeader(slide, title, subtitle = "") {
  slide.addShape("rect", { x: 0, y: 0, w: 10, h: 0.72, fill: { color: WHITE }, line: { color: WHITE } });
  slide.addShape("rect", { x: 0, y: 0, w: 0.18, h: 0.72, fill: { color: GOLD }, line: { color: GOLD } });
  slide.addText(title, {
    x: 0.35, y: 0, w: 9.3, h: 0.72, fontSize: 22, bold: true,
    color: NAVY, valign: "middle", margin: 0,
  });
  if (subtitle) {
    slide.addText(subtitle, {
      x: 0.35, y: 0.72, w: 9.3, h: 0.32, fontSize: 11,
      color: MUTED, valign: "middle", margin: 0, italic: true,
    });
  }
}

// Stat callout card
function addStatCard(slide, x, y, w, h, stat, label) {
  slide.addShape("rect", { x, y, w, h, fill: { color: WHITE }, line: { color: LIGHT_CARD }, shadow: makeShadow() });
  slide.addText(stat, { x, y: y + 0.1, w, h: h * 0.55, fontSize: 32, bold: true, color: GOLD, align: "center", valign: "bottom" });
  slide.addText(label, { x, y: y + h * 0.58, w, h: h * 0.38, fontSize: 11, color: MUTED, align: "center", valign: "top" });
}

// Section label badge
function addBadge(slide, x, y, text) {
  slide.addShape("rect", { x, y, w: 1.6, h: 0.28, fill: { color: GOLD }, line: { color: GOLD } });
  slide.addText(text, { x, y, w: 1.6, h: 0.28, fontSize: 9, bold: true, color: WHITE, align: "center", valign: "middle" });
}

// Footer
function addFooter(slide, text = "Book Recommender System · NLP Project · EADA Business School") {
  slide.addText(text, {
    x: 0, y: 5.35, w: 10, h: 0.27, fontSize: 8, color: MUTED, align: "center", valign: "middle",
  });
}

// ── SLIDE 1: TITLE ────────────────────────────────────────────────────────────
function slide01_title(pres) {
  const s = darkSlide(pres);

  // Decorative gold rectangle top
  s.addShape("rect", { x: 0, y: 0, w: 10, h: 0.18, fill: { color: GOLD }, line: { color: GOLD } });
  // Decorative gold rectangle bottom
  s.addShape("rect", { x: 0, y: 5.44, w: 10, h: 0.18, fill: { color: GOLD }, line: { color: GOLD } });

  // Book icon placeholder - two overlapping rectangles
  s.addShape("rect", { x: 4.1, y: 0.7, w: 1.4, h: 1.8, fill: { color: GOLD, transparency: 20 }, line: { color: GOLD } });
  s.addShape("rect", { x: 4.5, y: 0.6, w: 1.4, h: 1.8, fill: { color: "C4922A" }, line: { color: "A07020" } });
  s.addText("📖", { x: 4.1, y: 0.65, w: 1.8, h: 1.8, fontSize: 54, align: "center", valign: "middle" });

  s.addText("Book Recommender System", {
    x: 0.5, y: 2.6, w: 9, h: 0.85, fontSize: 38, bold: true,
    color: WHITE, align: "center", charSpacing: 1,
  });
  s.addText("Natural Language Processing · EADA Business School", {
    x: 0.5, y: 3.5, w: 9, h: 0.4, fontSize: 16,
    color: GOLD, align: "center", italic: true,
  });

  // Team members row
  s.addShape("rect", { x: 1.5, y: 4.15, w: 7, h: 0.04, fill: { color: GOLD, transparency: 40 }, line: { color: GOLD, transparency: 40 } });
  s.addText("Team · Member 1 · Member 2 · Member 3 · Member 4", {
    x: 0.5, y: 4.25, w: 9, h: 0.35, fontSize: 13,
    color: MUTED, align: "center",
  });
}

// ── SLIDE 2: PROBLEM DEFINITION ───────────────────────────────────────────────
function slide02_problem(pres) {
  const s = lightSlide(pres);
  addHeader(s, "Problem Definition", "Why is book discovery hard?");

  // Left: problem statement
  s.addShape("rect", { x: 0.35, y: 1.1, w: 5.5, h: 3.7, fill: { color: WHITE }, line: { color: LIGHT_CARD }, shadow: makeShadow() });
  s.addText("The Challenge", { x: 0.55, y: 1.2, w: 5.1, h: 0.38, fontSize: 14, bold: true, color: NAVY });
  s.addText([
    { text: "Genre search is too broad", options: { bullet: true, breakLine: true } },
    { text: "Search engines favour bestsellers, not similar content", options: { bullet: true, breakLine: true } },
    { text: "No easy way to find books that match your current read", options: { bullet: true, breakLine: true } },
    { text: "Rating alone does not predict personal taste", options: { bullet: true } },
  ], { x: 0.55, y: 1.65, w: 5.1, h: 2.8, fontSize: 13, color: DARK, lineSpacingMultiple: 1.4 });

  // Right: our solution
  s.addShape("rect", { x: 6.15, y: 1.1, w: 3.5, h: 3.7, fill: { color: NAVY }, line: { color: NAVY }, shadow: makeShadow() });
  s.addText("Our Solution", { x: 6.3, y: 1.2, w: 3.2, h: 0.38, fontSize: 14, bold: true, color: GOLD });
  s.addText([
    { text: "Content-based NLP recommender", options: { bullet: true, breakLine: true } },
    { text: "Understands book descriptions, genres, and author style", options: { bullet: true, breakLine: true } },
    { text: "Works from a simple text input", options: { bullet: true, breakLine: true } },
    { text: "Explainable pipeline — no black-box model", options: { bullet: true } },
  ], { x: 6.3, y: 1.65, w: 3.2, h: 2.8, fontSize: 12, color: WHITE, lineSpacingMultiple: 1.45 });

  addFooter(s);
}

// ── SLIDE 3: DATASET OVERVIEW ─────────────────────────────────────────────────
function slide03_dataset(pres) {
  const s = lightSlide(pres);
  addHeader(s, "Dataset Overview", "books.csv — 6,810 books, 12 columns");

  // Stat cards row
  addStatCard(s, 0.35, 0.9,  2.1, 1.15, "6,810",  "Total Books");
  addStatCard(s, 2.65, 0.9,  2.1, 1.15, "3,780",  "Unique Authors");
  addStatCard(s, 4.95, 0.9,  2.1, 1.15, "567",    "Genre Categories");
  addStatCard(s, 7.25, 0.9,  2.3, 1.15, "3.93★",  "Avg Rating");

  // Column table
  s.addText("Columns used by the recommender", { x: 0.35, y: 2.2, w: 4.5, h: 0.3, fontSize: 11, bold: true, color: NAVY });
  const tableData = [
    [{ text: "Column",      options: { bold: true, color: WHITE, fill: { color: NAVY } } },
     { text: "Role",        options: { bold: true, color: WHITE, fill: { color: NAVY } } },
     { text: "Used?",       options: { bold: true, color: WHITE, fill: { color: NAVY } } }],
    ["title",       "Primary signal (weight ×3)",    "✔ Yes"],
    ["categories",  "Genre signal (weight ×2)",       "✔ Yes"],
    ["authors",     "Author context (weight ×1)",     "✔ Yes"],
    ["description", "Content signal (weight ×1)",     "✔ Yes"],
    ["average_rating", "Author ranking sort",         "✔ Yes"],
    ["thumbnail / isbn / subtitle", "No semantic value", "✘ No"],
  ];
  s.addTable(tableData, {
    x: 0.35, y: 2.55, w: 4.7, h: 2.5,
    colW: [1.6, 2.0, 1.1],
    border: { pt: 0.5, color: "E0E0E0" },
    fontSize: 10,
    color: DARK,
    fill: { color: WHITE },
    rowH: 0.34,
  });

  // Chart: top categories
  s.addText("Top categories", { x: 5.25, y: 2.2, w: 4.4, h: 0.3, fontSize: 11, bold: true, color: NAVY });
  s.addImage({ path: path.join(CHARTS, "top_categories.png"), x: 5.25, y: 2.55, w: 4.4, h: 2.5 });

  addFooter(s);
}

// ── SLIDE 4: DATA DISTRIBUTIONS ──────────────────────────────────────────────
function slide04_distributions(pres) {
  const s = lightSlide(pres);
  addHeader(s, "Dataset Analysis", "Distributions & data quality");

  // Rating chart
  s.addText("Rating Distribution", { x: 0.35, y: 0.85, w: 4.6, h: 0.28, fontSize: 12, bold: true, color: NAVY });
  s.addImage({ path: path.join(CHARTS, "rating_distribution.png"), x: 0.35, y: 1.15, w: 4.6, h: 2.3 });

  // Decade chart
  s.addText("Books by Publication Decade", { x: 5.15, y: 0.85, w: 4.5, h: 0.28, fontSize: 12, bold: true, color: NAVY });
  s.addImage({ path: path.join(CHARTS, "books_per_decade.png"), x: 5.15, y: 1.15, w: 4.5, h: 2.3 });

  // Missing values chart
  s.addText("Missing Values", { x: 0.35, y: 3.55, w: 4.6, h: 0.28, fontSize: 12, bold: true, color: NAVY });
  s.addImage({ path: path.join(CHARTS, "missing_values.png"), x: 0.35, y: 3.85, w: 4.6, h: 1.5 });

  // Key insights
  s.addShape("rect", { x: 5.15, y: 3.55, w: 4.5, h: 1.8, fill: { color: WHITE }, line: { color: LIGHT_CARD }, shadow: makeShadow() });
  s.addText("Key Insights", { x: 5.3, y: 3.65, w: 4.2, h: 0.3, fontSize: 12, bold: true, color: NAVY });
  s.addText([
    { text: "Ratings cluster around 3.5 – 4.5 (high quality bias)", options: { bullet: true, breakLine: true } },
    { text: "80% of books published after 2000", options: { bullet: true, breakLine: true } },
    { text: "subtitle missing for 65% — safely excluded", options: { bullet: true, breakLine: true } },
    { text: "Only 1.1% missing authors; 1.5% missing categories", options: { bullet: true } },
  ], { x: 5.3, y: 4.0, w: 4.2, h: 1.3, fontSize: 11, color: DARK, lineSpacingMultiple: 1.4 });

  addFooter(s);
}

// ── SLIDE 5: NLP PIPELINE OVERVIEW ───────────────────────────────────────────
function slide05_pipeline(pres) {
  const s = lightSlide(pres);
  addHeader(s, "NLP Pipeline Overview", "From raw CSV to ranked recommendations");

  const steps = [
    { label: "1  Load Data",       sub: "CSV → DataFrame\nValidate columns",       x: 0.3  },
    { label: "2  Preprocess",      sub: "Combine fields\nClean text",               x: 2.15 },
    { label: "3  Vectorize",       sub: "TF-IDF sparse\nmatrix  +  SBERT",          x: 4.0  },
    { label: "4  Similarity",      sub: "Cosine sim\nN×N matrix",                   x: 5.85 },
    { label: "5  Recommend",       sub: "Route  →  Rank\nReturn top-N",             x: 7.7  },
  ];

  steps.forEach(({ label, sub, x }) => {
    s.addShape("rect", { x, y: 1.05, w: 1.8, h: 1.6,
      fill: { color: NAVY }, line: { color: NAVY }, shadow: makeShadow() });
    s.addText(label, { x, y: 1.12, w: 1.8, h: 0.5, fontSize: 11, bold: true, color: GOLD, align: "center" });
    s.addText(sub,   { x, y: 1.65, w: 1.8, h: 0.9, fontSize: 9.5, color: WHITE, align: "center", valign: "top" });
  });

  // Arrows between boxes
  [0.3, 2.15, 4.0, 5.85].forEach(x => {
    s.addShape("rect", { x: x + 1.8, y: 1.8, w: 0.35, h: 0.08, fill: { color: GOLD }, line: { color: GOLD } });
    s.addText("▶", { x: x + 1.87, y: 1.66, w: 0.2, h: 0.38, fontSize: 12, color: GOLD });
  });

  // Startup vs Request labels
  s.addShape("rect", { x: 0.3, y: 2.85, w: 5.35, h: 0.35, fill: { color: GOLD, transparency: 70 }, line: { color: GOLD, transparency: 40 } });
  s.addText("⚡  Computed ONCE at startup — not on every request", {
    x: 0.35, y: 2.85, w: 5.25, h: 0.35, fontSize: 10, color: NAVY, valign: "middle", bold: true });

  s.addShape("rect", { x: 7.7, y: 2.85, w: 1.8, h: 0.35, fill: { color: NAVY, transparency: 20 }, line: { color: NAVY, transparency: 40 } });
  s.addText("Per request", { x: 7.7, y: 2.85, w: 1.8, h: 0.35, fontSize: 10, color: WHITE, valign: "middle", align: "center" });

  // Smart routing box
  s.addShape("rect", { x: 0.35, y: 3.38, w: 9.3, h: 1.85, fill: { color: WHITE }, line: { color: LIGHT_CARD }, shadow: makeShadow() });
  s.addText("Smart Routing  —  smart_recommend(user_input)", {
    x: 0.55, y: 3.48, w: 8.9, h: 0.35, fontSize: 13, bold: true, color: NAVY });

  const routes = [
    { icon: "📖", label: "Exact title match",  desc: "→  TF-IDF cosine similarity" },
    { icon: "✍️", label: "Author name match",  desc: "→  Author search, sorted by rating" },
    { icon: "💬", label: "Free-text query",    desc: "→  Sentence-BERT semantic search" },
  ];
  routes.forEach(({ icon, label, desc }, i) => {
    const x = 0.55 + i * 3.1;
    s.addText(icon + " " + label, { x, y: 3.9, w: 3.0, h: 0.32, fontSize: 11, bold: true, color: NAVY });
    s.addText(desc,               { x, y: 4.22, w: 3.0, h: 0.85, fontSize: 10, color: MUTED });
  });

  addFooter(s);
}

// ── SLIDE 6: PREPROCESSING ───────────────────────────────────────────────────
function slide06_preprocessing(pres) {
  const s = lightSlide(pres);
  addHeader(s, "Preprocessing Pipeline", "src/preprocessing.py");

  // Weights diagram
  s.addText("Weighted combined_text", { x: 0.35, y: 0.95, w: 4.8, h: 0.3, fontSize: 13, bold: true, color: NAVY });

  const fields = [
    { name: "title",       weight: 3, w: 4.4, color: NAVY },
    { name: "categories",  weight: 2, w: 2.9, color: "2A5F8C" },
    { name: "authors",     weight: 1, w: 1.4, color: TEAL },
    { name: "description", weight: 1, w: 1.4, color: MUTED },
  ];
  let cx = 0.35;
  fields.forEach(({ name, weight, w, color }) => {
    s.addShape("rect", { x: cx, y: 1.28, w, h: 0.55, fill: { color }, line: { color } });
    s.addText(`${name} ×${weight}`, { x: cx, y: 1.28, w, h: 0.55, fontSize: 9.5, bold: true, color: WHITE, align: "center", valign: "middle" });
    cx += w + 0.06;
  });
  s.addText("→  combined_text  (cleaned)", { x: cx, y: 1.28, w: 2.0, h: 0.55, fontSize: 10, color: MUTED, valign: "middle" });

  // clean_text steps
  s.addText("clean_text() steps", { x: 0.35, y: 2.05, w: 4.8, h: 0.3, fontSize: 13, bold: true, color: NAVY });

  const steps = [
    ["1", "Lowercase",        "\"Harry Potter\" → \"harry potter\""],
    ["2", "Remove punctuation","[^a-z0-9\\s] → space"],
    ["3", "Remove numbers",   "digits stripped"],
    ["4", "Remove stopwords", "NLTK English: 'the', 'and', 'of' removed"],
    ["5", "Strip whitespace", "collapse multiple spaces, trim"],
  ];
  steps.forEach(([num, step, example], i) => {
    const y = 2.42 + i * 0.5;
    s.addShape("rect", { x: 0.35, y, w: 0.32, h: 0.38, fill: { color: GOLD }, line: { color: GOLD } });
    s.addText(num,     { x: 0.35, y, w: 0.32, h: 0.38, fontSize: 11, bold: true, color: WHITE, align: "center", valign: "middle" });
    s.addText(step,    { x: 0.75, y: y + 0.01, w: 2.2, h: 0.38, fontSize: 11, bold: true, color: DARK });
    s.addText(example, { x: 3.0,  y: y + 0.01, w: 4.0, h: 0.38, fontSize: 10, color: MUTED, italic: true });
  });

  // Why? note
  s.addShape("rect", { x: 5.35, y: 1.0, w: 4.3, h: 4.2, fill: { color: WHITE }, line: { color: LIGHT_CARD }, shadow: makeShadow() });
  s.addText("Why these choices?", { x: 5.5, y: 1.1, w: 4.0, h: 0.32, fontSize: 13, bold: true, color: NAVY });
  s.addText([
    { text: "Why title ×3?", options: { bold: true, breakLine: true } },
    { text: "Titles are the most distinctive signal — a book's topic is almost always in the title.", options: { breakLine: true, color: MUTED } },
    { text: " ", options: { breakLine: true } },
    { text: "Why categories ×2?", options: { bold: true, breakLine: true } },
    { text: "Genre is a stronger similarity signal than author or description.", options: { breakLine: true, color: MUTED } },
    { text: " ", options: { breakLine: true } },
    { text: "Why NLTK stopwords?", options: { bold: true, breakLine: true } },
    { text: "Words like 'the', 'a', 'of' appear in all books and carry zero discriminative power for TF-IDF.", options: { breakLine: true, color: MUTED } },
    { text: " ", options: { breakLine: true } },
    { text: "Why strip numbers?", options: { bold: true, breakLine: true } },
    { text: "Edition years and page references would pollute the vocabulary without adding semantic value.", options: { color: MUTED } },
  ], { x: 5.5, y: 1.5, w: 4.0, h: 3.6, fontSize: 11, color: DARK, lineSpacingMultiple: 1.3 });

  addFooter(s);
}

// ── SLIDE 7: TF-IDF ──────────────────────────────────────────────────────────
function slide07_tfidf(pres) {
  const s = lightSlide(pres);
  addHeader(s, "TF-IDF Vectorization", "From text to numbers — and why it works");

  // Left: concept
  s.addShape("rect", { x: 0.35, y: 0.95, w: 4.8, h: 4.3, fill: { color: WHITE }, line: { color: LIGHT_CARD }, shadow: makeShadow() });
  s.addText("What is TF-IDF?", { x: 0.5, y: 1.05, w: 4.5, h: 0.35, fontSize: 14, bold: true, color: NAVY });

  s.addText([
    { text: "TF  (Term Frequency)", options: { bold: true, breakLine: true } },
    { text: "How often does a word appear in THIS book?", options: { color: MUTED, breakLine: true } },
    { text: " ", options: { breakLine: true } },
    { text: "IDF  (Inverse Document Frequency)", options: { bold: true, breakLine: true } },
    { text: "How rare is this word across ALL books? Rare = more informative.", options: { color: MUTED, breakLine: true } },
    { text: " ", options: { breakLine: true } },
    { text: "TF-IDF  =  TF × IDF", options: { bold: true, breakLine: true } },
    { text: "High score = word is frequent here but rare elsewhere → distinctive.", options: { color: MUTED, breakLine: true } },
    { text: " ", options: { breakLine: true } },
    { text: "Cosine Similarity", options: { bold: true, breakLine: true } },
    { text: "Measures the angle between two TF-IDF vectors. 1 = identical, 0 = nothing in common. Length-independent, so a short description is fairly compared to a long one.", options: { color: MUTED } },
  ], { x: 0.5, y: 1.45, w: 4.5, h: 3.75, fontSize: 11, color: DARK, lineSpacingMultiple: 1.35 });

  // Right: implementation
  s.addShape("rect", { x: 5.35, y: 0.95, w: 4.3, h: 4.3, fill: { color: NAVY }, line: { color: NAVY }, shadow: makeShadow() });
  s.addText("Implementation", { x: 5.5, y: 1.05, w: 4.0, h: 0.35, fontSize: 14, bold: true, color: GOLD });

  const params = [
    ["max_features",  "10,000",     "Vocabulary cap — top 10k most informative terms"],
    ["ngram_range",   "(1, 2)",     "Unigrams + bigrams: 'fantasy', 'dark fantasy'"],
    ["stop_words",    "english",    "Built-in sklearn stopword removal"],
    ["max_df",        "0.95",       "Drop words in >95% of books — too common"],
    ["min_df",        "1",          "Include all words that appear at least once"],
  ];
  params.forEach(([key, val, desc], i) => {
    const y = 1.5 + i * 0.72;
    s.addShape("rect", { x: 5.5, y, w: 1.35, h: 0.48, fill: { color: GOLD }, line: { color: GOLD } });
    s.addText(key, { x: 5.5, y, w: 1.35, h: 0.24, fontSize: 8.5, color: WHITE, align: "center", valign: "middle", bold: true });
    s.addText(val, { x: 5.5, y: y + 0.24, w: 1.35, h: 0.24, fontSize: 11, color: WHITE, align: "center", valign: "middle", bold: true });
    s.addText(desc, { x: 6.95, y, w: 2.6, h: 0.5, fontSize: 9.5, color: WHITE, valign: "middle" });
  });

  s.addText("Output: N × 10,000 sparse matrix  →  N×N cosine similarity matrix", {
    x: 5.5, y: 5.05, w: 4.0, h: 0.18, fontSize: 9, color: GOLD, italic: true });

  addFooter(s);
}

// ── SLIDE 8: SENTENCE-BERT ───────────────────────────────────────────────────
function slide08_sbert(pres) {
  const s = lightSlide(pres);
  addHeader(s, "Sentence-BERT: Semantic Search", "all-MiniLM-L6-v2 — understanding meaning, not just words");

  // Comparison table
  s.addText([
    { text: "TF-IDF vs Sentence-BERT", options: { bold: true } },
  ], { x: 0.35, y: 0.95, w: 9.3, h: 0.3, fontSize: 13, color: NAVY });

  const cmpData = [
    [{ text: "", options: { fill: { color: NAVY } } },
     { text: "TF-IDF",         options: { bold: true, color: WHITE, fill: { color: NAVY }, align: "center" } },
     { text: "Sentence-BERT",  options: { bold: true, color: WHITE, fill: { color: GOLD }, align: "center" } }],
    ["Representation",  "Sparse vector (word counts)",     "Dense embedding (384 dims)"],
    ["Semantics",       "Exact word match only",           "Synonyms, paraphrases understood"],
    ["Example",         "\"novel\" ≠ \"fiction\"",         "\"novel\" ≈ \"fiction\" ≈ \"book\""],
    ["Use in this app", "Title-based similarity",          "Free-text topic queries"],
    ["Speed",           "O(1) lookup (precomputed)",       "Encode query per request"],
  ];
  s.addTable(cmpData, {
    x: 0.35, y: 1.3, w: 9.3, h: 2.5, colW: [2.2, 3.35, 3.75],
    border: { pt: 0.5, color: "E0E0E0" },
    fontSize: 11, color: DARK, fill: { color: WHITE }, rowH: 0.4,
  });

  // How it works
  s.addShape("rect", { x: 0.35, y: 3.95, w: 9.3, h: 1.4, fill: { color: WHITE }, line: { color: LIGHT_CARD }, shadow: makeShadow() });
  s.addText("How SBERT works in this project", { x: 0.5, y: 4.05, w: 9.0, h: 0.32, fontSize: 13, bold: true, color: NAVY });

  const sbSteps = [
    { n: "1", t: "Startup:\nencode all 6,810 books",       x: 0.5  },
    { n: "2", t: "User enters:\n\"fantasy magic\"",         x: 2.7  },
    { n: "3", t: "Encode query\n→ 384-dim vector",          x: 4.9  },
    { n: "4", t: "Cosine sim vs\nall book embeddings",      x: 7.1  },
  ];
  sbSteps.forEach(({ n, t, x }) => {
    s.addShape("rect", { x, y: 4.42, w: 2.0, h: 0.75, fill: { color: NAVY }, line: { color: NAVY } });
    s.addText(n, { x, y: 4.42, w: 0.28, h: 0.75, fontSize: 10, bold: true, color: GOLD, align: "center", valign: "middle" });
    s.addText(t, { x: x + 0.32, y: 4.42, w: 1.6, h: 0.75, fontSize: 9, color: WHITE, valign: "middle" });
  });

  addFooter(s);
}

// ── SLIDE 9: SYSTEM ARCHITECTURE ─────────────────────────────────────────────
function slide09_architecture(pres) {
  const s = lightSlide(pres);
  addHeader(s, "System Architecture", "Layered design — each layer has one responsibility");

  const layers = [
    { label: "GUI Layer",              sub: "Gradio · src/app.py",              color: GOLD  },
    { label: "Recommendation Layer",   sub: "smart_recommend() · src/recommender.py", color: NAVY  },
    { label: "Similarity Engine",      sub: "TF-IDF N×N matrix  +  SBERT embeddings", color: "2A5F8C" },
    { label: "Vectorization Layer",    sub: "TfidfVectorizer  +  SentenceTransformer", color: "2A7F8C" },
    { label: "Preprocessing Layer",    sub: "load_data() → combined_text → clean_text()", color: MUTED },
    { label: "data/books.csv",         sub: "6,810 books · 12 columns",          color: DARK  },
  ];

  layers.forEach(({ label, sub, color }, i) => {
    const y = 0.95 + i * 0.72;
    const w = 9.3 - i * 0.4;
    const x = 0.35 + i * 0.2;
    s.addShape("rect", { x, y, w, h: 0.6, fill: { color }, line: { color } });
    s.addText(label, { x: x + 0.15, y, w: w * 0.45, h: 0.6, fontSize: 12, bold: true, color: WHITE, valign: "middle" });
    s.addText(sub,   { x: x + w * 0.5, y, w: w * 0.48, h: 0.6, fontSize: 10, color: i < 2 ? CREAM : WHITE, valign: "middle", italic: true });

    if (i < layers.length - 1) {
      s.addText("▼", { x: 4.7, y: y + 0.6, w: 0.5, h: 0.12, fontSize: 9, color: MUTED, align: "center" });
    }
  });

  // Key design principle
  s.addShape("rect", { x: 0.35, y: 5.2, w: 9.3, h: 0.3, fill: { color: GOLD, transparency: 75 }, line: { color: GOLD, transparency: 60 } });
  s.addText("All heavy computation runs once at startup. Serving a recommendation is a lightweight lookup, not a recomputation.", {
    x: 0.5, y: 5.2, w: 9.1, h: 0.3, fontSize: 10, color: NAVY, valign: "middle", bold: true });

  addFooter(s);
}

// ── SLIDE 10: LIVE DEMO ───────────────────────────────────────────────────────
function slide10_demo(pres) {
  const s = darkSlide(pres);
  s.addShape("rect", { x: 0, y: 0, w: 10, h: 0.18, fill: { color: GOLD }, line: { color: GOLD } });
  s.addShape("rect", { x: 0, y: 5.44, w: 10, h: 0.18, fill: { color: GOLD }, line: { color: GOLD } });

  s.addText("Live Demo", { x: 0.5, y: 1.5, w: 9, h: 0.75, fontSize: 42, bold: true, color: WHITE, align: "center" });
  s.addText("http://127.0.0.1:7860", { x: 0.5, y: 2.35, w: 9, h: 0.45, fontSize: 20, color: GOLD, align: "center", italic: true });

  const demos = [
    { icon: "📖", label: "Title input",  ex: "\"Gilead\"  →  similar books (TF-IDF)" },
    { icon: "✍️",  label: "Author input", ex: "\"Agatha Christie\"  →  her books by rating" },
    { icon: "💬", label: "Topic search", ex: "\"fantasy magic\"  →  semantic (SBERT)" },
  ];
  demos.forEach(({ icon, label, ex }, i) => {
    const x = 0.6 + i * 3.1;
    s.addShape("rect", { x, y: 3.1, w: 2.8, h: 1.6, fill: { color: WHITE, transparency: 10 }, line: { color: GOLD } });
    s.addText(icon,  { x, y: 3.2,  w: 2.8, h: 0.45, fontSize: 26, align: "center" });
    s.addText(label, { x, y: 3.65, w: 2.8, h: 0.3,  fontSize: 11, bold: true, color: GOLD, align: "center" });
    s.addText(ex,    { x, y: 3.95, w: 2.8, h: 0.65, fontSize: 9.5, color: WHITE, align: "center" });
  });

  s.addText("Run:  python src/app.py", {
    x: 2.5, y: 5.0, w: 5, h: 0.3, fontSize: 11, color: MUTED, align: "center", italic: true });
}

// ── SLIDE 11: LIMITATIONS ────────────────────────────────────────────────────
function slide11_limitations(pres) {
  const s = lightSlide(pres);
  addHeader(s, "Limitations", "Honest assessment of what the system cannot do");

  const items = [
    { title: "Content-only",        desc: "No user history or personalization. Every user gets the same recommendations for the same input." },
    { title: "Exact title match",   desc: "TF-IDF path requires the exact book title (case-insensitive). Partial titles or typos return 'not found'." },
    { title: "Bag-of-words",        desc: "TF-IDF misses semantics beyond n-grams — 'novel' and 'fiction' are treated as unrelated words." },
    { title: "English-only",        desc: "Stopwords and preprocessing are English-only. Non-English books get sub-optimal treatment." },
    { title: "In-memory scale",     desc: "Full N×N similarity matrix lives in RAM. Scaling to millions of books would require FAISS or ANN search." },
    { title: "Cold start",          desc: "Adding new books requires a full reload + recomputation of TF-IDF and similarity." },
  ];

  const cols = [items.slice(0, 3), items.slice(3)];
  cols.forEach((col, ci) => {
    col.forEach(({ title, desc }, ri) => {
      const x = 0.35 + ci * 4.9;
      const y = 0.92 + ri * 1.52;
      s.addShape("rect", { x, y, w: 4.65, h: 1.4, fill: { color: WHITE }, line: { color: LIGHT_CARD }, shadow: makeShadow() });
      s.addShape("rect", { x, y, w: 0.18, h: 1.4, fill: { color: GOLD }, line: { color: GOLD } });
      s.addText(title, { x: x + 0.28, y: y + 0.08, w: 4.3, h: 0.32, fontSize: 12, bold: true, color: NAVY });
      s.addText(desc,  { x: x + 0.28, y: y + 0.42, w: 4.3, h: 0.9,  fontSize: 10.5, color: DARK, lineSpacingMultiple: 1.3 });
    });
  });

  addFooter(s);
}

// ── SLIDE 12: FUTURE IMPROVEMENTS ────────────────────────────────────────────
function slide12_future(pres) {
  const s = lightSlide(pres);
  addHeader(s, "Future Improvements", "What would make this production-ready?");

  const items = [
    { icon: "🔍", title: "Fuzzy Search",       desc: "NearestNeighbors on title embeddings for partial/typo-tolerant title input." },
    { icon: "🤝", title: "Hybrid Filtering",    desc: "Combine content-based scores with collaborative filtering for personalized results." },
    { icon: "💾", title: "Caching",             desc: "Persist similarity matrix to disk; incremental indexing for new books." },
    { icon: "🌐", title: "REST API",            desc: "Expose as FastAPI service with versioning, health checks, rate limits." },
    { icon: "🎲", title: "Diversity",           desc: "MMR re-ranking after top-k retrieval to ensure genre spread in results." },
    { icon: "⚙️", title: "Config-driven",       desc: "Move field weights and TF-IDF hyperparameters to YAML for easy experimentation." },
  ];

  const cols = [items.slice(0, 3), items.slice(3)];
  cols.forEach((col, ci) => {
    col.forEach(({ icon, title, desc }, ri) => {
      const x = 0.35 + ci * 4.9;
      const y = 0.92 + ri * 1.52;
      s.addShape("rect", { x, y, w: 4.65, h: 1.4, fill: { color: WHITE }, line: { color: LIGHT_CARD }, shadow: makeShadow() });
      s.addText(icon,  { x, y: y + 0.08, w: 0.85, h: 1.2, fontSize: 26, align: "center", valign: "middle" });
      s.addText(title, { x: x + 0.9, y: y + 0.12, w: 3.6, h: 0.34, fontSize: 12, bold: true, color: NAVY });
      s.addText(desc,  { x: x + 0.9, y: y + 0.48, w: 3.6, h: 0.85, fontSize: 10.5, color: DARK, lineSpacingMultiple: 1.3 });
    });
  });

  addFooter(s);
}

// ── SLIDE 13: CLOSING ─────────────────────────────────────────────────────────
function slide13_closing(pres) {
  const s = darkSlide(pres);
  s.addShape("rect", { x: 0, y: 0,    w: 10, h: 0.18, fill: { color: GOLD }, line: { color: GOLD } });
  s.addShape("rect", { x: 0, y: 5.44, w: 10, h: 0.18, fill: { color: GOLD }, line: { color: GOLD } });

  s.addText("Thank You", {
    x: 0.5, y: 1.3, w: 9, h: 0.9, fontSize: 48, bold: true, color: WHITE, align: "center" });

  s.addText("Questions?", {
    x: 0.5, y: 2.3, w: 9, h: 0.55, fontSize: 22, color: GOLD, align: "center", italic: true });

  s.addShape("rect", { x: 2.5, y: 3.0, w: 5, h: 0.04, fill: { color: GOLD, transparency: 40 }, line: { color: GOLD, transparency: 40 } });

  const links = [
    "python src/app.py  →  http://127.0.0.1:7860",
    "python -m src.recommender \"Gilead\" 5",
    "python test_recommender.py",
  ];
  links.forEach((l, i) => {
    s.addText(l, { x: 1, y: 3.25 + i * 0.42, w: 8, h: 0.38, fontSize: 12, color: MUTED, align: "center", italic: true });
  });

  s.addText("Book Recommender System · NLP Project · EADA Business School", {
    x: 0.5, y: 4.95, w: 9, h: 0.28, fontSize: 9, color: MUTED, align: "center" });
}

// ── MAIN ──────────────────────────────────────────────────────────────────────
async function main() {
  const pres = new pptxgen();
  pres.layout  = "LAYOUT_16x9";
  pres.title   = "Book Recommender System — NLP Project";
  pres.subject = "EADA Business School · NLP Course";
  pres.author  = "Team";

  slide01_title(pres);
  slide02_problem(pres);
  slide03_dataset(pres);
  slide04_distributions(pres);
  slide05_pipeline(pres);
  slide06_preprocessing(pres);
  slide07_tfidf(pres);
  slide08_sbert(pres);
  slide09_architecture(pres);
  slide10_demo(pres);
  slide11_limitations(pres);
  slide12_future(pres);
  slide13_closing(pres);

  await pres.writeFile({ fileName: OUT });
  console.log("✅  Saved:", OUT);
}

main().catch(err => { console.error(err); process.exit(1); });
