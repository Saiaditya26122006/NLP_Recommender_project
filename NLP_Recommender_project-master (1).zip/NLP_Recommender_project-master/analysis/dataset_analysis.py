"""
Dataset analysis for the Book Recommender System.

Run from the project root:
    python analysis/dataset_analysis.py

Generates charts saved to analysis/charts/ and prints a summary to stdout.
Requires: pip install matplotlib seaborn
"""

import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")  # headless backend
import matplotlib.pyplot as plt
import matplotlib.ticker as mtick
import pandas as pd
import seaborn as sns

# ── paths ─────────────────────────────────────────────────────────────────────
PROJECT_ROOT = Path(__file__).resolve().parent.parent
DATA_PATH = PROJECT_ROOT / "data" / "books.csv"
CHARTS_DIR = Path(__file__).resolve().parent / "charts"
CHARTS_DIR.mkdir(exist_ok=True)

# ── palette ───────────────────────────────────────────────────────────────────
NAVY   = "#1E3A5F"
GOLD   = "#C4922A"
CREAM  = "#F5F0E8"
TEAL   = "#2A7F8C"
MUTED  = "#7B8EA0"

sns.set_theme(style="whitegrid", font_scale=1.1)
plt.rcParams.update({"font.family": "DejaVu Sans", "figure.dpi": 150})


def load():
    df = pd.read_csv(DATA_PATH)
    return df


# ── 1. top categories bar chart ───────────────────────────────────────────────
def plot_top_categories(df):
    top = df["categories"].value_counts().head(10)
    fig, ax = plt.subplots(figsize=(9, 5))
    bars = ax.barh(top.index[::-1], top.values[::-1], color=NAVY, edgecolor="none")
    for bar in bars:
        ax.text(bar.get_width() + 20, bar.get_y() + bar.get_height() / 2,
                f"{int(bar.get_width()):,}", va="center", fontsize=10, color=MUTED)
    ax.set_xlabel("Number of Books", color=MUTED)
    ax.set_title("Top 10 Categories", fontsize=14, fontweight="bold", color=NAVY, pad=12)
    ax.tick_params(colors=MUTED)
    ax.spines[["top", "right", "left"]].set_visible(False)
    ax.grid(axis="x", color="#E0E0E0", linewidth=0.6)
    fig.tight_layout()
    out = CHARTS_DIR / "top_categories.png"
    fig.savefig(out, bbox_inches="tight")
    plt.close(fig)
    print(f"  Saved: {out}")


# ── 2. rating distribution histogram ─────────────────────────────────────────
def plot_rating_distribution(df):
    ratings = df["average_rating"].dropna()
    fig, ax = plt.subplots(figsize=(8, 4))
    ax.hist(ratings, bins=30, color=GOLD, edgecolor="white", linewidth=0.5)
    ax.axvline(ratings.mean(), color=NAVY, linewidth=2, linestyle="--",
               label=f"Mean: {ratings.mean():.2f}")
    ax.axvline(ratings.median(), color=TEAL, linewidth=2, linestyle=":",
               label=f"Median: {ratings.median():.2f}")
    ax.set_xlabel("Average Rating", color=MUTED)
    ax.set_ylabel("Number of Books", color=MUTED)
    ax.set_title("Rating Distribution", fontsize=14, fontweight="bold", color=NAVY, pad=12)
    ax.legend(frameon=False, fontsize=10)
    ax.tick_params(colors=MUTED)
    ax.spines[["top", "right"]].set_visible(False)
    fig.tight_layout()
    out = CHARTS_DIR / "rating_distribution.png"
    fig.savefig(out, bbox_inches="tight")
    plt.close(fig)
    print(f"  Saved: {out}")


# ── 3. books per decade bar chart ─────────────────────────────────────────────
def plot_books_per_decade(df):
    df = df.copy()
    df["decade"] = (df["published_year"].dropna() // 10 * 10).astype(int)
    counts = df["decade"].value_counts().sort_index()
    counts = counts[counts.index >= 1940]  # focus on modern era
    fig, ax = plt.subplots(figsize=(9, 4))
    colors = [GOLD if d == 2000 else NAVY for d in counts.index]
    ax.bar(counts.index.astype(str), counts.values, color=colors, edgecolor="none", width=0.7)
    ax.set_xlabel("Decade", color=MUTED)
    ax.set_ylabel("Number of Books", color=MUTED)
    ax.set_title("Books Published by Decade (1940–2019)", fontsize=14,
                 fontweight="bold", color=NAVY, pad=12)
    ax.tick_params(colors=MUTED, axis="x", rotation=45)
    ax.tick_params(colors=MUTED, axis="y")
    ax.spines[["top", "right"]].set_visible(False)
    ax.grid(axis="y", color="#E0E0E0", linewidth=0.6)
    fig.tight_layout()
    out = CHARTS_DIR / "books_per_decade.png"
    fig.savefig(out, bbox_inches="tight")
    plt.close(fig)
    print(f"  Saved: {out}")


# ── 4. missing values bar chart ───────────────────────────────────────────────
def plot_missing_values(df):
    missing_pct = (df.isnull().sum() / len(df) * 100).sort_values(ascending=False)
    missing_pct = missing_pct[missing_pct > 0]
    fig, ax = plt.subplots(figsize=(8, 4))
    colors = [GOLD if p > 10 else NAVY for p in missing_pct.values]
    bars = ax.bar(missing_pct.index, missing_pct.values, color=colors, edgecolor="none")
    for bar in bars:
        h = bar.get_height()
        ax.text(bar.get_x() + bar.get_width() / 2, h + 0.5,
                f"{h:.1f}%", ha="center", va="bottom", fontsize=9, color=MUTED)
    ax.set_ylabel("Missing (%)", color=MUTED)
    ax.set_title("Missing Values by Column", fontsize=14, fontweight="bold", color=NAVY, pad=12)
    ax.yaxis.set_major_formatter(mtick.PercentFormatter())
    ax.tick_params(colors=MUTED, axis="x", rotation=30)
    ax.tick_params(colors=MUTED, axis="y")
    ax.spines[["top", "right"]].set_visible(False)
    ax.grid(axis="y", color="#E0E0E0", linewidth=0.6)
    fig.tight_layout()
    out = CHARTS_DIR / "missing_values.png"
    fig.savefig(out, bbox_inches="tight")
    plt.close(fig)
    print(f"  Saved: {out}")


# ── 5. print summary ──────────────────────────────────────────────────────────
def print_summary(df):
    print("\n" + "="*55)
    print("  DATASET SUMMARY")
    print("="*55)
    print(f"  Total books       : {len(df):,}")
    print(f"  Unique authors    : {df['authors'].nunique():,}")
    print(f"  Unique categories : {df['categories'].nunique():,}")
    print(f"  Year range        : {int(df['published_year'].min())} – {int(df['published_year'].max())}")
    print(f"  Avg rating        : {df['average_rating'].mean():.2f}  (std {df['average_rating'].std():.2f})")
    print(f"  Median ratings cnt: {df['ratings_count'].median():,.0f}")
    print(f"  Avg pages         : {df['num_pages'].mean():.0f}")
    print()
    print("  Top 5 categories:")
    for cat, n in df["categories"].value_counts().head(5).items():
        print(f"    {cat:<35} {n:>5,}")
    print()
    print("  Top 5 authors:")
    for auth, n in df["authors"].value_counts().head(5).items():
        print(f"    {auth:<35} {n:>5,}")
    print("="*55 + "\n")


# ── main ──────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    print("\nLoading dataset...")
    df = load()
    print(f"Loaded {len(df):,} books.\n")

    print("Generating charts...")
    plot_top_categories(df)
    plot_rating_distribution(df)
    plot_books_per_decade(df)
    plot_missing_values(df)

    print_summary(df)
    print(f"All charts saved to: {CHARTS_DIR}/")
